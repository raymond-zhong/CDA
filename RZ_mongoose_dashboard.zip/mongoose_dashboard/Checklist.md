Checklist:

1.dependencies:
-express
-ejs
-body-parser
-mongoose
-path

2. views
-index, new, edit, show

3. create server
-routes
  -logic
    -add a new cat to the database

4. connection to database to server
  -create model for data cat (cats)
