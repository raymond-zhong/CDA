//Dependencies
var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var path = require('path');
var port = 3000;

// Create express app
var app = express();

// Use bodyParser to parse from data sent via HTTP post
app.use(bodyParser.urlencoded({ extended:true}));

// Tell server where views are and what templating engine using
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

//Create connection to database
var connection = mongoose.connect("mongodb://localhost/cat_db");

//Create cat schema and attach it as a model to our database
var CatSchema = new mongoose.Schema({
    name: String,
    weight: Number,
    color: String
});

//Mongoose automatically looks for the plural version of your model name, so a Cat model in Mongoose looks for 'cats' in Mongo.
var Cat = mongoose.model('Cat', CatSchema);

// Routes go here!
app.get('/', function(req, res){
  Cat.find({}, function(err, results){
    if (err) {console.log(err); }
    res.render('index', {cats: results});
  });
});
app.get('/cat/new', function(req, res){
    res.render('new');
});
app.get('/cat/:id', function(req, res){
  Cat.find({_id: req.params.id}, function(err, response){
    if (err) {console.log(err); }
    res.render('show',{cat:response[0]});
  });
});
app.get('/cat/:id/edit', function(req, res){
    Cat.find({_id: req.params.id}, function(err, response){
      if (err) {console.log(err); }
      console.log("CAT:", response)
      res.render('edit',{cat:response[0]});
    });
});

app.post('/cat', function(req, res){
  //Create a new cat!
  Cat.create(req.body, function(err, result){
    if (err) { console.log(err);}
    res.redirect('/');
  });
});
app.post('/cat/:id', function(req, res){
  Cat.update({_id: req.params.id},req.body, function(err, result){
    if (err) { console.log(err);}
    res.redirect('/');
  });
});
app.post('/cat/:id/destroy', function(req, res){
  Cat.remove({_id: req.params.id}, function(err, result){
    if (err) { console.log(err);}
    res.redirect('/');
  });
});
app.listen(port, function(){
  console.log("Running on", port);
})
