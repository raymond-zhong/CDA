var mongoose = require('mongoose');

// var PersonSchema = new mongoose.Schema({
//     name: String
// });

//Mongoose automatically looks for the plural version of your model name, so a Cat model in Mongoose looks for 'cats' in Mongo.
// var Person = mongoose.model('Person', PersonSchema);
