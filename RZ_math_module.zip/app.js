var math = require('./mathlib');
math.add1(2,3);
math.multiply(3,5);
math.square(5);
math.random(1,35);
